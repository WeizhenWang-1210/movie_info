<?php

$host = 'localhost';
$dbuser ='cs143';
$dbpassword = '';
$dbname = 'class_db';
$link = mysqli_connect($host,$dbuser,$dbpassword,$dbname);

// if($link){
//     mysqli_query($link,'SET NAMES uff8');
//     echo "正確連接資料庫<br>";
// }

?>